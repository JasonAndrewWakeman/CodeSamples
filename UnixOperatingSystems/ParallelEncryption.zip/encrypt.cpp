#ifndef encrypt
#define encrypt
#include "encrypt.h" 

//The 'main' function of the application which asks a user for a buffer size; creates, spawns, and joins threads and then prints the counts in each file specified by the command line arguments..

int main(int argc, char* argv[]) {


  
    //check against the wrong number of arguments
	if (argc != 3){
      	cout << "Improper Usage Of Encrypt: Incorrect number of arguments!" << endl ;
	return 0; 
    }

    cin.clear();
    
    cout << "Enter buffer size: " ;
    
    
    cin >> bufferSize;
    //error handling if the input is not an integer
	if (cin.fail()) {
   	   cout << "Invalid usage of Encrypt: you did not enter an integer for the buffersize!" << endl; 
	   return 0; 
	}
    
    cin.clear(); //ignore any superfluous input
    cin.sync();  //synchronize with the console
    cin.get();

	//allocate the correct amount of memory to the input and output local buffers of size bufferSize

	buffer = (char*) malloc(bufferSize*sizeof(char));
		if (buffer==NULL) {
		printf("Error allocating memory!\n"); //print an error message
		return 1; //return with failure
	}
    
	
        outBuffer = (char*) malloc(bufferSize*sizeof(char));
		if (outBuffer==NULL) {
		printf("Error allocating memory!\n"); //print an error message
		return 1; //return with failure
	}


    //sets the filebuffers to be the same size as the local buffers
    fb->pubsetbuf(0, bufferSize);
    outFB->pubsetbuf(0, bufferSize);

    //opens the files as streams to the input and ouput filebuffers
  	fb->open (argv[1], ios::in);
  	outFB->open (argv[2], ios::out);
  	
  	//if either of the files were unable to be opened prints an error message and exits the program.
  	if (!( fb->is_open() && outFB->is_open()))
	{
    	std::cout << "A file could not be opened. Improper Usage Of Encrypt: Incorrect formatting of arguments! \n";
    	return 0; 
	}
	else
	{    
		//create the threads with appropriate thread ids
		pthread_t readThread;
		pthread_t inCountThread;
		pthread_t encryptThread;
		pthread_t outCountThread;
		pthread_t writeThread;
		
		//initializes the state variables to be 1 if they should wait or 0 if they should proceed right away.
		rcDone = 1;
		eDone = 1;
		wcDone = 1; 
		wfDone = 1; 
		inBuffFull4Count = 0; 
		inBuffFull4Encrypt = 0;
		outBuffFull4Count = 0; 
    		outBuffFull4Write = 0; 

		//spawn the threads at their respective functions // only null attributes and returns. all data is altered on global variables
		pthread_create(&readThread, NULL, readIn, NULL);
		pthread_create(&inCountThread, NULL, countIn, NULL);
		pthread_create(&encryptThread, NULL, encryptData, NULL);
		pthread_create(&outCountThread, NULL, countOut, NULL);
		pthread_create(&writeThread, NULL, writeOut, NULL);


		//wait for all of the threads to return indicating that every char from the file has been read to the buffer, encrypted, and written to outfile
		pthread_join(readThread, NULL);
		pthread_join(inCountThread, NULL);
		pthread_join(encryptThread, NULL);
		pthread_join(outCountThread, NULL);
		pthread_join(writeThread, NULL);
	
		cout << "Input file contains" << endl ;

		for(int i = 65; i < 91; i++){

			//only print something if the letter is not null
			if(inFileCount[i].ct != 0){
		  	  cout << (char)inFileCount[i].ch << ": " << inFileCount[i].ct << endl;
			}
		}
		cout << "Output file contains" << endl ;

		for(int i = 65; i < 91; i++){

			//only print something if the letter is not null
			if(outFileCount[i].ct != 0){
		  	  cout << (char)outFileCount[i].ch << ": " << outFileCount[i].ct << endl;
			}
		}
	} 

    //closes the file buffers which closes their respective streams.
    fb->close();
    outFB->close(); 

    //frees the space allocated to the buffers. 
    free(buffer);
    free(outBuffer);

    return 0; 
}

#endif 
