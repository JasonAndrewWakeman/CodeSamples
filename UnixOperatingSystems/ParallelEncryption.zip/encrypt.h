//More than just a header file. Here we also have 5 thread functions as well as two helper functions for the encrypt thread. the helper functions perform the wrap around, while the thread functions offer concurrency in file i/o and the processing of data. 
//Author:  Jason Wakeman ---November 19, 2015--- Iowa State University --- Com Sci 352  

#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <pthread.h>
#include <stdlib.h>
#include <assert.h>
#include <cerrno>
#include <limits.h>
#include <fcntl.h>
#include <pthread.h>

using namespace std;


static pthread_mutex_t binding = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t outBinding = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t readBufferFull = PTHREAD_COND_INITIALIZER;
static pthread_cond_t readCountDone = PTHREAD_COND_INITIALIZER;
static pthread_cond_t encryptDone = PTHREAD_COND_INITIALIZER;
static pthread_cond_t outBufferFull = PTHREAD_COND_INITIALIZER;
static pthread_cond_t writeCountDone = PTHREAD_COND_INITIALIZER;
static pthread_cond_t writeFileDone = PTHREAD_COND_INITIALIZER;

int rcDone;
int eDone;
int wcDone; 
int wfDone; 
int inBuffFull4Count;  
int inBuffFull4Encrypt;
int outBuffFull4Count; 
int outBuffFull4Write; 

//used to store character and count in infile count array and outfile count array
typedef struct pair_struct{
  int ct;
  int ch;
    }Pair;

//the table completed by countInFile() 
Pair inFileCount[91];

//the table completed by countOutFile() 
Pair outFileCount[91];

//declares an input file stream
ifstream is;
//declares an ouput file steam
ofstream os; 
//instantiates a intermediary buffer associated with the input stream
filebuf * fb = is.rdbuf();
//instantiates a intermediary buffer associated with the output stream
filebuf * outFB = os.rdbuf(); 
//instantiates an int which will be used as the size of all buffers
int bufferSize  = 0; 


//the input buffer which will be allocated to size n by main function.
char *buffer;
char *outBuffer;  



 

void* readIn(void *arg){

//
char inFocus; 
   
while(true){

  pthread_mutex_lock(&binding);

while (rcDone == 0){
  //wait until readCountDone
  pthread_cond_wait(&readCountDone, &binding);
  }

while (eDone == 0){
  //wait until encrypt thread completes
  pthread_cond_wait(&encryptDone, &binding);
 }
 

  for(int i = 0; i < bufferSize; i++){
    
    inFocus = (char)fb->sbumpc(); 
    if (inFocus == EOF){
      //Now we know the end of the file has been reached so we write EOF and return. 
      buffer[i] = inFocus; 
      rcDone = 0;
      eDone = 0;
      inBuffFull4Count = 1;  //this will be decremented when countIn finish 
      inBuffFull4Encrypt = 1;  //this will be decremented when encrypt finish
      pthread_cond_broadcast(&readBufferFull);
      pthread_mutex_unlock(&binding);//unlocks the binding around buffer now that it is finished using it. 

      pthread_exit(NULL); 
    }
    else{
      buffer[i] = inFocus; 
    } 
  }//ends for loop

  rcDone = 0;
  eDone = 0;
  inBuffFull4Count = 1;
  inBuffFull4Encrypt = 1;  

  pthread_cond_broadcast(&readBufferFull);
  pthread_mutex_unlock(&binding);//unlocks the binding around buffer now that it is finished using it.
  } 
 }

 

//thread function which goes through each character in the input buffer and increments the ct variable of the value corresponding to the character in dictionary

void* countIn(void *arg){
  //used as an incrementing index in the table and to keep track of how many pairs have been added  
  int numberOfPairsInput = 0;

  //sets each pair in the table to have null values initially
  for (int i = 0; i < 26; i++)
  {
    Pair *ini = new Pair; 

    //since A is the int 65 and Z is 90 we add 65 to i as the offset.
    ini->ch = 65 + i;
    inFileCount[i + 65] = *ini ;
  } 

  char temp; 
  
  while(true){
   
    pthread_mutex_lock(&binding);
    //wait until readBufferFull
    while(inBuffFull4Count == 0){
    pthread_cond_wait(&readBufferFull, &binding);
  }
  
  for (int i = 0; i < bufferSize; i++){
      temp = buffer[i];

    if (temp == EOF){


      inBuffFull4Count = 0; 
      rcDone = 1; 
      pthread_cond_signal(&readCountDone);
      pthread_mutex_unlock(&binding);  //unlocks the buffer now that it is done with it.
      pthread_exit(NULL);
      }

      if (isalpha((int) temp) == 0) // if this returns zero it is not a letter so we do not add it to table
      {
        goto NextChar;
      }

      else //look up temp in dictionary and increment its count by 1
      {
        for (int j = 65; j <= 90; j++)
        {
          if (inFileCount[j].ch == (int)toupper((int)temp) ) //then increment the count of this Pair
          {
            inFileCount[j].ct++ ; 
            goto NextChar; 
          }
        }
        //we must add a new pair with temp as key and 1 as value.
        
        Pair *pairToInsert = new Pair;
        pairToInsert->ch = (int)toupper((int)temp);
        pairToInsert->ct = 1; 
        inFileCount[numberOfPairsInput] = *pairToInsert;
        //increment the numberOfPairsInput
        numberOfPairsInput++;    

      }

      NextChar:
      ; 
    }//end for (each char in buffer) loop
    inBuffFull4Count = 0; 
    rcDone = 1; 
    //signals that the contents of buffer have been counted
    pthread_cond_signal(&readCountDone);
    pthread_mutex_unlock(&binding);  //unlocks the buffer now that it is done with it.
  }
}


  //the helper function for encryptData. called when s = 1.  returns the next higher letter to the char passed in or 'a' if 'z' is passed in. 
  char wrapAroundUp(char ch)

    {
      if (ch == 'z'){ return 'a'; }
      else if (ch == 'Z' ){ return 'A'; }
      else 
      {
        return static_cast<char>(ch + 1);
      }
    }

  //the helper function for encryptData. called when s = -1.  returns the next lower letter to the char passed in or 'z' if 'a' is passed in. 
  char wrapAroundDown(char ch) 

    {
      if (ch == 'a'){ return 'z'; }
      else if (ch == 'A' ){ return 'Z'; }
      else 
      {
        return static_cast<char>(ch - 1);
      }
    }

void* encryptData(void *arg){

  int s; 
  char temp;
    
  s = 1;  
  while (true){
    pthread_mutex_lock(&binding);//locks the binding around buffer in order to use it. 
   
    while(inBuffFull4Encrypt == 0){
      pthread_cond_wait(&readBufferFull, &binding);
    }

    pthread_mutex_lock(&outBinding);//locks the outBinding around outBuffer in order to use it. 
   
    while(wcDone == 0){
      pthread_cond_wait(&writeCountDone, &outBinding);
    }  


    while(wfDone == 0){
      pthread_cond_wait(&writeFileDone, &outBinding);
    }

   for (int i = 0; i < bufferSize; i++){
      temp = buffer[i];
//cout << temp << endl; 
      if (temp == EOF){
//cout << "we reached the end of file in encrypt  and temp is: " << temp << endl ;
        outBuffer[i] = temp; 
        inBuffFull4Encrypt = 0; 
        eDone = 1; 
        outBuffFull4Count = 1; 
        outBuffFull4Write = 1; 
        wcDone = 0;
        wfDone = 0; 
      
        pthread_cond_signal(&encryptDone);
        pthread_cond_broadcast(&outBufferFull);
        pthread_mutex_unlock(&binding);//unlocks the binding around buffer now that it is finished using it.
        pthread_mutex_unlock(&outBinding);//unlocks the outBinding around outBuffer now that it is finished using it. 
        pthread_exit(NULL);
      }
      //checks to see if c is a letter, if it is not it skips the encryption
      if (isalpha((int) temp) == 0){

        //skip the encryption
        goto TransferChar; 
      }
      else // temp is an alphabetic character, so we check s's value and encrypt accordingly. 
      {
        if (s == 1) //we must increase c by 1 or wrap around and set s to -1
        {  
          temp = wrapAroundUp(temp); 
          s = -1; 
          goto TransferChar; 
        }
        else if(s == -1) //we must decrease c by 1 or wrap around and set s to 0
        {
     
          temp = wrapAroundDown(temp);  
          s = 0; 
          goto TransferChar;     
        }

        else //just set s to be 1 because it must be 0
        {
          s = 1; 
        }
      
      }

    
      TransferChar:
      outBuffer[i] = temp; 
    }//end for loop

    inBuffFull4Encrypt = 0; 
    eDone = 1; 
    outBuffFull4Count = 1; 
    outBuffFull4Write = 1; 
    wcDone = 0;
    wfDone = 0; 

    pthread_cond_signal(&encryptDone);
    pthread_cond_broadcast(&outBufferFull);
    pthread_mutex_unlock(&binding);//unlocks the binding around buffer now that it is finished using it.
    pthread_mutex_unlock(&outBinding);//unlocks the outBinding around outBuffer now that it is finished using it.  
  }
}

//goes through each character in the output buffer and increments the ct variable of the value corresponding to the character in dictionary

void* countOut(void *arg){
 //used as an incrementing index in the table and to keep track of how many pairs have been added  
  int numberOfPairsOutput = 0;

  //sets each pair in the table to have a NULL count and a corresponding int value for ch to each of the 26 UpperCase characters in English alphebet. 
  for (int i = 0; i < 26; i++)
  {
    Pair *ini = new Pair; 

    //since A is the int 65 and Z is 90 we add 65 to i as the offset.
    ini->ch = 65 + i;
    outFileCount[i + 65] = *ini ;
  } 

  char temp; 
  while(true){
    pthread_mutex_lock(&outBinding);//locks the outBinding around outBuffer in order to use it. 

    while( outBuffFull4Count == 0 ){
      pthread_cond_wait(&outBufferFull, &outBinding);
    }

    for (int i = 0; i < bufferSize; i++){
      temp = outBuffer[i];

      if (temp == EOF){
        //the end of the file has been reached so we can stop and terminate thread.
        wcDone = 1; 
        outBuffFull4Count = 0; 

        pthread_cond_signal(&writeCountDone);
        pthread_mutex_unlock(&outBinding);//unlocks the binding around buffer now that it is done with it.  
        pthread_exit(NULL);
      }

      if (isalpha((int) temp) == 0) // if this returns zero it is not a letter so we do not add it to table
      {
        goto NextChar;
      }
      else //look up temp in dictionary and increment its count by 1
      {
        for (int j = 65; j <= 90; j++)
        {
          if (outFileCount[j].ch == (int)toupper((int)temp) ) //then increment the count of this Pair
          {
            outFileCount[j].ct++ ; 
            goto NextChar; 
          }
        }
        //we must add a new pair with temp as key and 1 as value.
        
        Pair *pairToInsert = new Pair;
        pairToInsert->ch = (int)toupper((int)temp);
        pairToInsert->ct = 1; 
        outFileCount[(int)toupper((int)temp)] = *pairToInsert;
        //increment the numberOfPairsInput
        numberOfPairsOutput++;    
      }
      NextChar:
      ; 
    }//end for loop

    wcDone = 1; 
    outBuffFull4Count = 0; 
    pthread_cond_signal(&writeCountDone);
    pthread_mutex_unlock(&outBinding);//unlocks the binding around buffer now that it is done with it. 
  }
}

//a pthread function which takes in a NULL and returns a NULL
//writes the contents of the buffer to the outfile
 
void* writeOut(void *arg){
  while(true){

    pthread_mutex_lock(&outBinding);//locks the outBinding around outBuffer in order to use it. 

    while( outBuffFull4Write == 0 ){
      pthread_cond_wait(&outBufferFull, &outBinding);
    }
  

    for(int i = 0; i < bufferSize; i++){
    
      if(outBuffer[i] == EOF){
   //     outFB->sputc(outBuffer[i]); 
        outBuffFull4Write = 0; 
        wfDone = 1;   
  
        pthread_cond_signal(&writeFileDone);//unlocks the outBinding around outBuffer now that it is finished using it. 
        pthread_mutex_unlock(&outBinding);//unlocks the outBinding around outBuffer now that it is finished using it. 
        pthread_exit(NULL);
      }

      outFB->sputc(outBuffer[i]); 

    }
    outBuffFull4Write = 0; 
    wfDone = 1; 
  
    pthread_cond_signal(&writeFileDone);//signals (to encrypt)  that the contents of buffer have been written to file. 
    pthread_mutex_unlock(&outBinding);//unlocks the outBinding around outBuffer now that it is finished using it. 
  }
}
