#include <iostream>
#include <stdio.h>
#include <string.h>
#include <cstdlib>
#include <pthread.h>
#include <stdlib.h>
#include <assert.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sstream>
#include <cerrno>
#include <limits.h>
#include <fcntl.h>
#include <sys/stat.h>


using namespace std;
int MAX_JOBS = 1001;
struct bgProcess {
  int jobNum;
  string name;
  int status;
  int waitStatus;
} ;

struct bgProcessTable {
  bgProcess * procArray = new bgProcess[MAX_JOBS];
} bgTable;



int main() {
	int MAX_ARGS = sysconf(_SC_ARG_MAX);
	const char *REDIR_IN = {"<"};
	const char *REDIR_OUT = {">"};
	string str = ""	;
	int activeJobs = 0;
	int nextJobNum;
  bool treatAsBG;
	int i;
	bool redirection;
  bool pipes;
	pid_t pid = 0;
  bool printRunning;
  bool printFinished;
  bool *finishedList;
  int pipeCount; 
  char *pipeCommandCharArr[31][128]; 
 	
	while (true) {

  //checks to see if there are any running background jobs-- if not resets the background table's jobNum index
     
	  treatAsBG = false;
	  redirection = false;
	  printRunning = false;
    printFinished = false;
    pipes = false;
    redirection = false; 
    cin.clear();
	  cout.clear();
	  int fdIn = -1;
	  int fdOut = -1;
    int numOfWords = 0;
    char *pipeCommandArr[128];
    pipeCount = 0; 
  
    char *pipeCommandArgs[128][128];


    if (activeJobs == 0) {
      nextJobNum = 0;
    }
   
    //creates an array of strings the size of the maximum number of allowed arguments by Pyrite
   string *commandArr = new string[MAX_ARGS];
    
	  cout << "wsh: ";

 	 //if there is not a line in standard input print a statement.
    if (!getline(cin, str)){
      cout << "please enter a valid command" << endl;
    }  

    
    stringstream ss(str);
   

    //determines the number of words in the commandand puts each one into commandArr
  	while (ss.good()){	
      ss >> commandArr[numOfWords];
      numOfWords++;    
    }
    //creates a constant character * array of the size of the number of words.
    const char * commandCharArr[numOfWords];



    i = 0;
    //converts each word in the command line to a char array and places it in the array
    while (i < numOfWords){
      commandCharArr[i] =  commandArr[i].c_str();	
      i++ ;
		}

		//checks to see if one of the three built in commands is applicable

		if((strcmp("cd", commandCharArr[0]) == 0) && numOfWords > 1) {

		  int ret = chdir(commandCharArr[1]);
		  //the change in directory could not occur.
		  if (ret == -1) {
        cout << "this is not a valid path to a directory "  << endl;
      }
        //the change in directory occured and we need to print the new working directory.
        else{

        	char * buf = new char[127];
     		  cout << "working directory: " << getcwd(buf, 127) << endl; 
     	    delete[] buf;
        }
          
		}

		else if((strcmp("wait", commandCharArr[0]) == 0) && numOfWords == 2) {
      int dummy = atoi(commandCharArr[1]);
		  if(dummy < 0 || dummy > nextJobNum){
        cout << "please enter a valid job number" << endl ; 
        goto nextIt; 
      }
      else{
        
        if (bgTable.procArray[dummy].name[0] != '\0'){
          int pidToWaitFor = bgTable.procArray[dummy].status ; 
          cout << "waiting for " << bgTable.procArray[dummy].name << endl;
        
          if (waitpid(pidToWaitFor, NULL, 0) == -1){ //means this did not work 
              cout << "there is a problem with waiting for that job" << endl;
              goto nextIt; 
          }
          else{ //print the finished job and change its status and decrement activeJobs
             bgTable.procArray[dummy].status = -1; 
             activeJobs--; 
             cout << "Finished: " << endl;
             cout << "    [" << dummy << "] " << bgTable.procArray[dummy].name << endl ;           
             goto nextIt; 
          }
        }
      }
      
		}

		else if(strcmp("exit", commandCharArr[0]) == 0){
		_exit(EXIT_SUCCESS);
		
		}

    
      //checks to see if there are at least two arguments 
    else{; 
     // if(numOfWords < 2){
       // cout << "not a valid command" << endl ; 
    //    goto nextIt; 
      //}
    }

  	//checks to see if the last word is an ampersand, and if so conduct remaining operations as though a command for background.
  	if(strcmp("&", commandCharArr[numOfWords - 1]) == 0 ){
  		treatAsBG = true;
  	}

    //checks to see if there are any pipes in the command line, 
      i = 0;
   
      while (i < numOfWords){
        if ((strcmp(commandCharArr[i], "|") == 0)){
          pipeCount++;
         //if found set pipes to true
          pipes = true;
        }  
        i++ ;
      }

      if (pipes){
        i = 0;
        int p = 0; 
        int innerWordCount = 0; 
        while (p < numOfWords){
         
          if ((strcmp(commandCharArr[p], "|") == 0)) {

               pipeCommandArgs[i][innerWordCount] = NULL;
          i++; 
          innerWordCount = 0;
          p++; 

          }
          else{
            
            pipeCommandCharArr[i][innerWordCount] = commandArr[p].c_str()  ;
            pipeCommandArgs[i][innerWordCount] = const_cast<char*>(pipeCommandCharArr[i][innerWordCount]); 
            p++; 
            innerWordCount++;
          }
        } 
      }

	  //checks to see if there are any redirections in the command line, 
		//if so changes stdin or out accordingly  commandArgs[i] = const_cast<char*>(commandCharArr[i]);

	    i = 0;
      while (i < numOfWords){
        if ((strcmp(commandCharArr[i], "<") == 0) && (numOfWords >= i)){
        //try to open the next word as a file in readonly mode and then set that file's fd as stdin
      	  fdIn = open(commandCharArr[i+1], O_RDONLY);
          //if fdIn is -1, then we had an error and should return to beginning of while loop
      	   if (fdIn == -1) {
             fprintf(stderr, "this file is not able to be opened(%s)", strerror(errno));
             cout << endl;
             goto nextIt;
            }
          //if successful set redirection to true
      	  redirection = true;
        }

        else if ((strcmp(commandCharArr[i], ">") == 0) && (numOfWords >= i)){
        	
          //try to open the next word as a file in writeable mode and then set that file's fd as stdout
      	  //creates a file if it does not exist
          fdOut = open(commandCharArr[i+1], O_WRONLY | O_TRUNC | O_CREAT);
           if (fdOut == -1) {
            fprintf(stderr, "this is not a valid file to be written to (%s)", strerror(errno));
            cout << endl;
            goto nextIt;
           }
          //if successful set redirection as true
      	  redirection = true; 
        }
  
        i++ ;
	    }
	
	    char *commandArgs[128];


    //if there are pipes we do not need to worry about  redirection or bg processes

    if(pipes){

      //create the parent's pipe

      int pipePar[2];
      pipe(pipePar); 

      int pipefds[((pipeCount) * 2)]; //creates an int array of size 2 time number of pipes

       if ((pipe(pipefds)) != 0){//creates the first pipe with two consecutive file descriptors starting at i * 2
            cout << "Unable to create first pipe" << endl ;
          }
      //for each pipe job, create a new image we will keep track of i because this is the ith job and will call the ith commandArgs and set the i * 2 and i *2 + 1 file descriptors
      for(i = 1; i < pipeCount; i++){
        int numFileDs = (i * 2);
         if ((pipe(pipefds + numFileDs)) != 0){//creates a pipe with two consecutive file descriptors starting at i * 2
            cout << "Unable to create " << i << "th pipe" << endl ;
          }

      }
      for(i = 0; i <= pipeCount; i++){
        pid = fork();
     
        if (pid == -1){
          cout << "an error occured during the forking process and the child never forked." << endl;
          goto nextIt;
        } 
        else if (pid > 0){ //we know this is the parent process
          
          int ret = dup2(pipefds[i + 0], 1);
              if ( ret == -1){
                fprintf(stderr, "Could not perform dup2 command (%s) \n", strerror(errno));
               goto nextIt; 
              }
          
    
         
        }
        else if (pid == 0) { //we know pid is 0 so this must be the copied call. we will use this thread to do the ith things
          // replace standard input with input file if an accessible input file is provided
          //pipe(pipefd[]);

          if(i == 0){ //this is the first job and only needs to write from stdout to the read part of the first pipe
           
              //now we close the remaining file descriptors from 1 to ((pipeCount + 1) * 2)) because we have 2 for every job;
      
              for (int q = 1; q < ((pipeCount) * 2) ; q++){
                close(pipefds[q]); 
              }
  
              int ret = dup2(pipefds[i + 0], 1);
              if ( ret == -1){
                fprintf(stderr, "Could not perform dup2 command (%s) \n", strerror(errno));
                _exit(EXIT_FAILURE);
              }
          
            }
            else if(i == pipeCount){ //for the last job set only its stdin to the write side of the last pipe; leave its standard output to be to the console
                
            int ret3 = dup2(pipePar[1],1); 
                  
              if ( ret3 == -1){
                fprintf(stderr, "Could not perform pipe command (%s) \n", strerror(errno));
                _exit(EXIT_FAILURE);
              }
                for (int q = 0; q < ((i * 2) -1); q++){ //for all q which aren't the last file descriptor close the corresponding file descriptor
                  close(pipefds[q]); 
                }
                int ret = dup2(pipefds[((i * 2) - 1)], 0);  
                  
              if ( ret == -1){
                fprintf(stderr, "Could not perform pipe command (%s) \n", strerror(errno));
                _exit(EXIT_FAILURE);
              }
             
            }
            else if ( (i != pipeCount) && (i != 0)){ // for all the middle jobs set its stdin to the output of the pipe for which the previous job is using to supply input to
                  //and and stdout to be the ith desriptor + 1
                 int ret1 = dup2(pipefds[((i * 2) -1)],0); 
                 int ret2 = dup2(pipefds[(i * 2)],1);
             
                if( ( ret1 == -1) ||  (ret2 = -1)){
                fprintf(stderr, "Could not perform redirection command (%s) \n", strerror(errno));
                _exit(EXIT_FAILURE);
                }


               for (int q = 0; q < ((pipeCount * 2)) ; q++){ //for all pipefds at index q which arent being used, close the corresponding file descriptor
                  if((q != ((i * 2) -1)) && (q != (i * 2) ) ){
                    close(pipefds[q]); 
                  }
                }
            }
            //now execute the ith command Argument
         
            int ret = execvp(*pipeCommandCharArr[0], pipeCommandCharArr[0]);
              
            if (ret == -1) {
             cout << "Could not perform the " << i << "th command" << endl ;
             exit(EXIT_FAILURE);
            }

            
          } 
        }
 
      for (int q = 0; q < ((pipeCount * 2)); q++){
        close(pipefds[q]); 
      }
      close(pipePar[0]);
      close(pipePar[1]); 
     
      goto nextIt; 
    }
    //we know there are no pipes
	  //if redirection is to occur create a null terminated array of arguments up to redirection character
      //if treatAsBG is set, then we will not wait for the child to return.
      else if (redirection && treatAsBG && !pipes){
      	i = 0;
      	while((i < numOfWords) && (strcmp(commandCharArr[i], REDIR_IN) != 0) && (strcmp(commandCharArr[i], REDIR_OUT)!= 0)  ){
  	        commandArgs[i] = const_cast<char*>(commandCharArr[i]);
     		i++;
  	  	}  
  	  	commandArgs[i] = NULL;

        pid = fork();
     
        if (pid == -1){
  
          cout << "an error occured during the forking process and the child never forked." << endl;
          goto nextIt;
        } 
        else if (pid > 0){ //we know this is the parent process
  
          //this lets us know the fork was successful
         if ((waitpid(pid, &bgTable.procArray[nextJobNum].waitStatus, WNOHANG) >= 0)){
       
          //sets the status of the process in the table to be the pid of the newly forked process    
          bgTable.procArray[nextJobNum].status = pid;
          str[str.length()-1] = '\0';
          //set the new string as process's name
          bgTable.procArray[nextJobNum].name = str; 
          nextJobNum++;
          activeJobs++;
          }
     
        } 
        else if (pid == 0) { //we know pid is 0 so this must be the copied call. 
          // replace standard input with input file if an accessible input file is provided

          sleep(10); 
          if(fdIn != -1){
           
            dup2(fdIn, 0);
              // close file descriptor
            close(fdIn);
          }
          
          if(fdOut != -1){
        
            dup2(fdOut, 1); 
              // close file descriptor
            close(fdOut);
          }
      
          int ret = execvp(commandCharArr[0], commandArgs); 
            
          if (ret == -1) {
           fprintf(stderr, "Could not perform  command (%s) \n", strerror(errno));
           exit(EXIT_FAILURE);
          }

        }  
 		
      }

    //if redirection is to occur create a null terminated array of arguments up to redirection character
      //and we are running in foreground, then we wait
      else if (redirection  && !treatAsBG && !pipes){
        i = 0;
        while((i < numOfWords) && (strcmp(commandCharArr[i], REDIR_IN) != 0) && (strcmp(commandCharArr[i], REDIR_OUT)!= 0)  ){
            commandArgs[i] = const_cast<char*>(commandCharArr[i]);
          i++;
        }  
        commandArgs[i] = NULL;

        pid = fork();
     
        if (pid == -1){
  
          cout << "an error occured during the forking process and the child never forked." << endl;
          goto nextIt; 
        } 
        else if (pid > 0){ //we know this is the parent process
  
         waitpid(pid, &bgTable.procArray[nextJobNum].waitStatus, 0);
   
        } 
        else if (pid == 0) { //we know pid is 0 so this must be the copied call. 
          // replace standard input with input file if an accessible input file is provided
          if(fdIn != -1){
           
            dup2(fdIn, 0);
              // close file descriptor
          close(fdIn);
          }
          
          if(fdOut != -1){
        
            dup2(fdOut, 1); 
              // close file descriptor
            close(fdOut);
          }
    

      int ret = execvp(commandCharArr[0], commandArgs); 
            
          if (ret == -1) {
           fprintf(stderr, "Could not perform  command (%s) \n", strerror(errno));
           exit(EXIT_FAILURE);
          }

        }  
    
      }

  

	    else if(treatAsBG  && !redirection && !pipes) {
   		
        i = 0;
        while((i < numOfWords) && (strcmp(commandCharArr[i], REDIR_IN) != 0) && (strcmp(commandCharArr[i], REDIR_OUT)!= 0)  ){
            commandArgs[i] = const_cast<char*>(commandCharArr[i]);
          i++;
        }

        commandArgs[i] = NULL;

   	   	pid = fork();
     
		    if (pid == -1){
	
          cout << "an error occured during the forking process and the child never forked." << endl;
          goto nextIt;
	    	} 
		    else if (pid > 0){ //we know this is the parent process
  
   		  //waitpid(pid, &status, WNOHANG);//this is going to let us go on if the process is still going.
   		    if ((waitpid(pid, &bgTable.procArray[nextJobNum].waitStatus, WNOHANG) >= 0)){
       
          bgTable.procArray[nextJobNum].status = pid;
           str[str.length()-1] = '\0';
          //set the new string as process's name
   		    bgTable.procArray[nextJobNum].name = str; 
   		    nextJobNum++;
   		    activeJobs++;
          }
		 
	    	} 
		    else if (pid == 0) { //we know pid is 0 so this must be the copied call. 

		      sleep(3);

		      int ret = execvp(commandCharArr[0], commandArgs); 
         
      	  if (ret == -1) {
             fprintf(stderr, "Could not run this command(%s) \n", strerror(errno));
             _exit(EXIT_FAILURE);
      	  }

		    }
    	}

	    else if (!treatAsBG && !redirection && !pipes) {
        i = 0;
        while((i < numOfWords) && (strcmp(commandCharArr[i], REDIR_IN) != 0) && (strcmp(commandCharArr[i], REDIR_OUT)!= 0)  ){
            commandArgs[i] = const_cast<char*>(commandCharArr[i]);
          i++;
        }  
        commandArgs[i] = NULL;

   		
	      pid = fork();
	
		    if (pid == -1){
	     	cout << "error: the process failed to fork" << endl ; 
        goto nextIt;
    	
	     	} 
	    	else if (pid > 0){
 
     	  	int retPID = waitpid(pid, NULL, 0);
            if (retPID == -1){
              cout << "the wait was not successful" << endl;
              goto nextIt;
            }

			
	    	}
		    else {
         
          int ret = execvp(commandCharArr[0], commandArgs); 
         
          if (ret == -1) {
             fprintf(stderr, "Could not run this command(%s) \n", strerror(errno));
             _exit(EXIT_FAILURE);
          }
		    }
    	}

	    else {
       ;
     }

    nextIt: ;

	cin.clear() ;
	cout.clear();
   
 //checks to see if there are any active background jobs running, and if there are lists them

      if(pid > 0){ // we only want to print when the parent process finishes the iteration
        finishedList = new bool[nextJobNum];
		    for (i = 0; i < nextJobNum; i++){
		      if(bgTable.procArray[i].status > 0){
             int returnedPID = waitpid(bgTable.procArray[i].status, &bgTable.procArray[i].waitStatus, WNOHANG);
             
             if (returnedPID > 0){// we know this process has completed so we move it to finish and set printFinished and decrenebt active jobs 
                finishedList[i] = true; 
                printFinished = true;
                bgTable.procArray[i].status = -1; 
                activeJobs--;
             }
             else{ //this process is still running, so we set printRunning
                printRunning = true;
             }
          }
        }
      }
  
      //Now we print the appropriate sets

      if(printRunning  == true) {
        cout << "Running: " << endl;
        for (i = 0; i < nextJobNum; i++){
          if(bgTable.procArray[i].status > 0){
            cout << "    [" << i << "] " << bgTable.procArray[i].name << endl ;
          }          
        }
      }

     if(printFinished  == true) {
        cout << "Finished: " << endl;
        for (i = 0; i < nextJobNum; i++){
          if(finishedList[i] == true){
            cout << "    [" << i << "] " << bgTable.procArray[i].name << endl ;
          }          
        }
        delete[] finishedList;
      }  
          
  
    
    }
  delete[] bgTable.procArray;
return 0;
}
